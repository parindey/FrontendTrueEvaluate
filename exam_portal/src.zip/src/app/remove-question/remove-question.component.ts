import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminService } from '../service/admin.service';

@Component({
  selector: 'app-remove-question',
  templateUrl: './remove-question.component.html',
  styleUrls: ['./remove-question.component.css']
})
export class RemoveQuestionComponent implements OnInit {

  question_id: number;
  form1: FormGroup;

  constructor(private adminService: AdminService, private router: Router) { }

  ngOnInit() {
    this.form1 = new FormGroup(
      {
      question_id : new FormControl('', [Validators.required,
        Validators.pattern('/^\d{10}$/')])
      }
    )
  }

  removingQuestion(){
    this.adminService.removequestion(this.question_id).subscribe(response =>{
      alert("question is removed")
    })
    this.router.navigate(['admin_dashboard']);
  }
}

export class Register {

    fullName:String;
    email:String;
    password:String;
    mobile:Number;
    city:String;
    state:String;
    dob:Date;
    Qualification:String;
    yoc:Number;
}

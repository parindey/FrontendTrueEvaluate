export class SearchStudent {
        technology:number;
        state:String;
        city:String;
        level:number;
        marks:number;
}

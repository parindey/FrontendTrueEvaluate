export class UserResponse {
    questionId:number;
    userAnswer:String;
}

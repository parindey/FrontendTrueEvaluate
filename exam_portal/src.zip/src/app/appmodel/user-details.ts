export class UserDetails {

    userId:number;
    full_name:String;
    email:String;
    password:String;
    city:String;
    state:String;
    dob:Date;
    Qualification:String;
    yoc:number;
}

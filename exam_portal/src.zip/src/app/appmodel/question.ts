export class Question {
    question_id:number;
    question:String;
    option_1:String;
    option_2:String;
    option_3:String;
    option_4:String;
    correct_option:String;
    course_id:number;
    level_id:number;
}

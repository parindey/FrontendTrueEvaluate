export class Login {
    email:String;
    password:String;
}
